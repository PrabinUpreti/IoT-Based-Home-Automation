<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "iot_home_automation";

// Create connection
// $conn = new mysqli($servername, $username, $password,$dbname);
// $sql = "SELECT Status FROM smartHome";
// $result = $conn->query($sql);
echo $result;
?>