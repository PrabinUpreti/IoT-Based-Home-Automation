function checkConnection(){
  // var x = document.cookie
  // if(!x){
  //   var name = prompt("Enter your name.")
  //   if(name == null ||  name == "" || name.trim().length == 0){
  //     document.getElementById("demo").innerHTML = "ERROR!! Reload the page.";
  //     return;
  //   }
  //   else{
  //     document.cookie = "name="+name;
  //     var xhttp = new XMLHttpRequest();
  //     xhttp.onreadystatechange = function(){
  //       if (this.readyState == 4 && this.status == 200){
  //         document.getElementById("demo").innerHTML = xhttp.responseText;
  //       }
  //     };
  //     xhttp.open("GET","http://127.0.0.1/IoT/server/checkConnection.php",true);
  //     xhttp.send();
  //   }
  // }
  window.location.href = "/IoT/client/home.html";

}